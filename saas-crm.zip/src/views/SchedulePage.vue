<template>
  <div class="schedule-page">
    <div class="page-actions">
      <div class="actions-left">
        <h1 class="page-title">📅 Расписание</h1>
      </div>
      <div class="actions-right">
        <AppButton variant="primary">➕ Добавить занятие</AppButton>
      </div>
    </div>

    <div class="content-card">
      <p>Функционал расписания в разработке...</p>
    </div>
  </div>
</template>
  
  <script setup lang="ts">
import AppButton from "@/components/UI/AppButton.vue";
</script>
  
  <style lang="scss" scoped>
.schedule-page {
  // Стили по необходимости
}
</style>